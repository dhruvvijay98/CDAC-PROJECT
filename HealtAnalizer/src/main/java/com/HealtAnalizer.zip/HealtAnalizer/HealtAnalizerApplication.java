package com.HealtAnalizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealtAnalizerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealtAnalizerApplication.class, args);
	}

}
